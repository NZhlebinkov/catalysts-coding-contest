import java.util.ArrayList;

public class Star {
    private String name;
    private int[] lightCurveArray;
    private ArrayList<GroupedInt> groupedLight;
    private int numOfFlares;
    private int numOfTransits;
    private int baseLuminosity;
    public static final double TRANSIT_MIN_DIMMING = 0.005;

    public Star(String name, int[] lightCurveArray) {
        this.name = name;
        this.lightCurveArray = lightCurveArray;
        groupedLight = new ArrayList<GroupedInt>();
        numOfFlares = 0;
        numOfTransits = 0;
        baseLuminosity = lightCurveArray[0];
    }

    public void groupLight() {
        GroupedInt currentLightValue = new GroupedInt(lightCurveArray[0]);
        groupedLight.add(currentLightValue);
        for(int i = 1; i != lightCurveArray.length; i++) {
            if(currentLightValue.number == lightCurveArray[i]) {
                currentLightValue.occurences++;
            }
            else {
                currentLightValue = new GroupedInt(lightCurveArray[i]);
                groupedLight.add(currentLightValue);
            }
        }
    }

    public void countEvents() {
        for(int i = 1; i < groupedLight.size(); i += 2) {
            if(groupedLight.get(i).number > baseLuminosity) {
                numOfFlares++;
            }
            else if (groupedLight.get(i).number <= baseLuminosity*(1-TRANSIT_MIN_DIMMING)
                     && groupedLight.get(i).occurences >= 5) {
                numOfTransits++;
            }
        }
    }

    public String getName() {
        return name;
    }

    public ArrayList<GroupedInt> getGroupedLight() {
        return groupedLight;
    }

    @Override
    public String toString() {
        String result = name;
        for(int i = 0; i != groupedLight.size(); i++) {
            result += " " + groupedLight.get(i).number + " " + groupedLight.get(i).occurences;
        }
        return result;
    }

    public String eventsString() {
        return name + " " + numOfFlares + " " + numOfTransits;
    }

}
