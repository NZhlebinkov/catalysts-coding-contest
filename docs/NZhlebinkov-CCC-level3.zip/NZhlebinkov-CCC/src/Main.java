import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scName = new Scanner(System.in);

        int levelNum = scName.nextInt();
        int fileNum = scName.nextInt();
        File myFile = new File("src/level"+levelNum+"-"+fileNum+".in");
        Scanner sc = null;

        try {
            sc = new Scanner(myFile);
        }catch (FileNotFoundException e) {
            System.out.println("No file");
            System.exit(-1);
        }

        int numOfStars = Integer.parseInt(sc.next());
        Star[] myStars = new Star[numOfStars];

        for(int i = 0; i != numOfStars; i++) {
            String starName = sc.next();
            int lightCurveArrayLength = Integer.parseInt(sc.next());
            int[] lightCurveArray = new int[lightCurveArrayLength];
            for(int j = 0; j != lightCurveArrayLength; j++) {
                lightCurveArray[j] = Integer.parseInt(sc.next());
            }
            myStars[i] = new Star(starName, lightCurveArray);
            myStars[i].groupLight();
            myStars[i].determineEvents();
        }

        String result = "";
        for(int i = 0; i < numOfStars; i++) {
            String hasPC = myStars[i].hasPlanetCandidate() ? "YES" : "NO";
            result += myStars[i].getName() + " " + hasPC + " ";
        }

        System.out.println(result);



    }
}
