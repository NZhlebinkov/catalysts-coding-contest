public class GroupedInt {
    int number;
    int occurences;

    public GroupedInt(int number, int occurences) {
        this.number = number;
        this.occurences = occurences;
    }

    public GroupedInt(int number) {
        this.number = number;
        occurences = 1;
    }

}
