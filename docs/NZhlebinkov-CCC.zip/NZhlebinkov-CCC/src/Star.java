import java.util.ArrayList;

public class Star {
    private String name;
    private int[] lightCurveArray;
    private ArrayList<GroupedInt> groupedLight;

    public Star(String name, int[] lightCurveArray) {
        this.name = name;
        this.lightCurveArray = lightCurveArray;
        groupedLight = new ArrayList<GroupedInt>();
    }

    public void groupLight() {
        GroupedInt currentLightValue = new GroupedInt(lightCurveArray[0]);
        groupedLight.add(currentLightValue);
        for(int i = 1; i != lightCurveArray.length; i++) {
            if(currentLightValue.number == lightCurveArray[i]) {
                currentLightValue.occurences++;
            }
            else {
                currentLightValue = new GroupedInt(lightCurveArray[i]);
                groupedLight.add(currentLightValue);
            }
        }
    }

    public ArrayList<GroupedInt> getGroupedLight() {
        return groupedLight;
    }

    @Override
    public String toString() {
        String result = name;
        for(int i = 0; i != groupedLight.size(); i++) {
            result += " " + groupedLight.get(i).number + " " + groupedLight.get(i).occurences;
        }
        return result;
    }
}
